export const ADDED = "todos/added";
export const TOGGLED = "todos/toggled";
export const COLORSELECTED = "todos/colorselected";
export const DELETED = "todos/deleted";
export const ALLCOMPLETED = "todos/allcompleted";
export const CLEARCOMPLETED = "todos/clearcompleted";