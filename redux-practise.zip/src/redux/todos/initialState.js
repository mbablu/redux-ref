const initialState = [
    {
        id: 1,
        text: "Learn React JS",
        completed: true,
    },
    {
        id: 2,
        text: "Learn Redux",
        completed: false,
        color: "red",
    }
]

export default initialState;