const initialState = {
    status: "All",
    colors: [],
}

export default initialState;