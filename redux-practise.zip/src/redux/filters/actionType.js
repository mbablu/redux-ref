export const STATUSCHANGED = "filters/statusChanged";
export const COLORCHANGED = "filters/colorChanged";